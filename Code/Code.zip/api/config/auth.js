module.exports ={

   'googleAuth': {
       'clientID' : '1056710173783-00k7c8he5utpi75h8jtn3183cns3suq1.apps.googleusercontent.com',
       'clientSecret': 'gqwU3jy3K-anElJ6Vf3j7Py6',
       //'callbackURL': 'http://localhost:3000/auth/google/callback'
       'callbackURL': 'http://vip.fiu.edu/auth/google/callback'

   }
};