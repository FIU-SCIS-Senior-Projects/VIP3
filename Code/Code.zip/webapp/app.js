angular.module('mainApp', [
	'textAngular',
	'vipHeader',
	'vipFooter',
    'vip-projects',		//Features Module
	'ProjectProposalController',
	'reviewProfile',
	'routes',
	'projectApplicationController',
	'userRegistrationController',
	'forgotPasswordController',
	'forgotPasswordService',
	'contactController',
	'userService',
    'toDoModule',
	'user-profile',
	'reviewRegistration',
	'folder',
	'reviewStudentApp',
	'reviewProjectProposals'
]);
