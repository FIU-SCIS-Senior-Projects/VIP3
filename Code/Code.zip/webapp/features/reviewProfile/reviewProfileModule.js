(function() {
    'use strict';

    angular.module('reviewProfile', []);

})();
