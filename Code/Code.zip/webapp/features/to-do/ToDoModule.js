(function() {
    'use strict';

    angular.module('toDoModule', []);

})();
