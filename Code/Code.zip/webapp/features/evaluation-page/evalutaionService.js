angular
    .module('evaluationController')
    .factory('evaluationService', contactService);

function contactService() {
}

